package aquarium.entities.fish;

public abstract class BaseFish {
    private String name;
    private String species;
    private int size;
    private double price;

    protected BaseFish(String name, String species, double price) {
        setName(name);
        setSpecies(species);
        setPrice(price);
    }

    public void setName(String name) {
        if (this.name == null || this.name.isEmpty()) {
            throw new NullPointerException("Fish name cannot be null or empty.");
        } else {
            this.name = name;
        }
    }

    public void setSpecies(String species) {
        if (this.species == null || this.species.isEmpty()) {
            throw new NullPointerException("Fish species cannot be null or empty.");
        } else {
            this.species = species;
        }
    }

    public void setPrice(double price) {
        if (price <= 0) {
            throw new IllegalArgumentException("Fish price cannot be below or equal to 0.");
        } else {
            this.price = price;
        }
    }

    public void eat() {
        size += 5;
    }
}
